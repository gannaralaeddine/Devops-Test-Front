export class Stock 
{
    libelleStock?: string
    qte?: number
    qteMin?:number
}
