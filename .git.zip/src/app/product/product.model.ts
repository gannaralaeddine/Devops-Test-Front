export class Product {
  idProduct?: number
  productCode?: string
  productDescription?: string
  productPrice?: number
}
